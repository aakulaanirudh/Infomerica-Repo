#NOTE- Make sure to change the name of the file to "app_blueprint" from "app__blueprint"

from flask import Flask, Blueprint

app_blueprint = Blueprint('app_blueprint', __name__)

@app_blueprint.route('/')
def hello_world():
    return "<h1>Welcome to Infomerica</h1>"

@app_blueprint.route('/about')
def about_page():
    return "<h1>About the page</h1>"

@app_blueprint.route('/contact')
def contact():
    return "<h1>Find the contact details here. Thanks</h1>"

app = Flask(__name__)
app.register_blueprint(app_blueprint)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
