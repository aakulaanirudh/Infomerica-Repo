from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':  # Use request.method instead of requests.method
        api_key = '6fa077e2be37f081c5affae6dddbc2ab'
        
        user_input = request.form.get('city')  # Get city from form input

        weather_data = requests.get(f"https://api.openweathermap.org/data/2.5/weather?q={user_input}&units=imperial&APPID={api_key}")

        if weather_data.json()['cod'] == '404':
            return "<h1>No city found</h1>"
        else:
            weather = weather_data.json()['weather'][0]['main']
            temp = round(weather_data.json()['main']['temp'])
            return f"<h1>The weather in {user_input} is {weather}. The temperature is {temp}°F.</h1>"

    return """
    <form method="POST">
        <label for="city">Enter City:</label>
        <input type="text" id="city" name="city" required>
        <button type="submit">Get Weather</button>
    </form>
    """

if __name__ == '__main__':
    app.run(debug=True)
