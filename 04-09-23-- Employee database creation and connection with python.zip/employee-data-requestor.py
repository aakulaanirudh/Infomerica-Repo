import mysql.connector as mysql

connection = mysql.connect(host="localhost", user="root", password="Anirudh@03", database="infomerica")

cursor = connection.cursor()

employee_id = int(input("Please enter the Employee ID: "))

query = "SELECT * FROM employee_data WHERE Employee_ID = %s"

cursor.execute(query, (employee_id,))

employee_data = cursor.fetchone()

if employee_data:
    print("Employee Details:")
    print("Employee ID:", employee_data[0])
    print("Employee Name:", employee_data[1])
    print("Date of Joining:", employee_data[2])
    print("Date of Birth:", employee_data[3])
    print("Status:", employee_data[4])
    print("Reporting Manager:", employee_data[5])
else:
    print("Employee ID not found in the database.")

cursor.close()
connection.close()
