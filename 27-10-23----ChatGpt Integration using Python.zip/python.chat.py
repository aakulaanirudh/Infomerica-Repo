import openai

openai.api_key = "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"

model_engine = "text-davinci-003"
prompt = "Which the best cricket team in the world?"

completion = openai.Completion.create(
    engine = model_engine,
    prompt= prompt,
    max_tokens = 1024,
    n=1,
    stop= None,
    temperature= 0.5,
)

response = completion.choices[0].text
print(response)
