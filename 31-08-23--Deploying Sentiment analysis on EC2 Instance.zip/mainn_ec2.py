from flask import Flask, render_template_string, request
from textblob import TextBlob
from langdetect import detect 

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def mainn():
    if request.method == 'POST':
        sentence = request.form.get('sentence')
        if len(sentence) < 15:
            error_message = "<h1>Input must be at least 15 characters long.</h1>"
            return render_template_string(
                """
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Sentiment Analysis</title>
                </head>
                <body>
                    <form method="POST" action="/">
                        <input type="text" name="sentence" placeholder="Enter your sentence">
                        <button type="submit">Analyze</button>
                    </form>
                    <p>{{ error_message }}</p>
                </body>
                </html>
                """,
                error_message=error_message
            )

        blob1 = TextBlob(sentence)
        polarity = blob1.sentiment.polarity
        
        detected_language = detect(sentence)

        if detected_language == 'en':
            if polarity < 0.25:
                sentiment = "negative"
            elif 0.25 <= polarity < 0.7:
                sentiment = "neutral"
            else:
                sentiment = "positive"
        else:
            sentiment = "Enter the input in English only"

        return render_template_string(
            f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Sentiment Analysis Result</title>
            </head>
            <body>
                <h1>Sentence: {sentence}</h1>
                <h2>Sentiment: {sentiment}</h2>
            </body>
            </html>
            """,
            sentence=sentence,
            sentiment=sentiment
        )
    
    return render_template_string(
        """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Sentiment Analysis</title>
        </head>
        <body>
            <form method="POST" action="/">
                <input type="text" name="sentence" placeholder="Enter your sentence">
                <button type="submit">Analyze</button>
            </form>
        </body>
        </html>
        """
    )

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=80)
