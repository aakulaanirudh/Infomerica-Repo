from dotenv import load_dotenv
import os
import openai

load_dotenv()

def chatgpt_response(prompt):
    openai_api_key = os.getenv('OPENAI_API_KEY')  # Load OpenAI API key

    # Set the OpenAI API key if it's available
    if openai_api_key:
        openai.api_key = openai_api_key

    response = openai.Completion.create(
        model="text-davinci-003",
        prompt=prompt,
        temperature=1,
        max_tokens=100
    )

    response_dict = response.get("choices")
    if response_dict and len(response_dict) > 0:
        prompt_response = response_dict[0]["text"]
    return prompt_response
