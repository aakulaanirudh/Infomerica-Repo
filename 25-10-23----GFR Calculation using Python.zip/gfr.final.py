def calculate_egfr(age, serum_creatinine, is_male):
    try:
        # Validate input values
        if age <= 0 or serum_creatinine <= 0:
            raise ValueError("Age and serum creatinine must be positive numbers.")
        
        # Apply appropriate medical guidelines
        if is_male:
            adjustment_factor = 1.0
        else:
            adjustment_factor = 0.742
        
        # Calculate eGFR using Mayo Quadratic equation
        egfr = 186 * (serum_creatinine ** (-1.154)) * (age ** (-0.203)) * adjustment_factor
        return egfr

    except ValueError as err:
        print("Error:", err)
        return None


# Example usage
age_input = int(input("Enter patient's age: "))
creatinine_input = float(input("Enter serum creatinine level (mg/dL): "))
gender_input = input("Enter patient's gender (M/F): ").upper()

if gender_input == "M":
    is_male_input = True
elif gender_input == "F":
    is_male_input = False
else:
    print("Invalid gender input. Please enter 'M' for male or 'F' for female.")
    exit()

egfr_result = calculate_egfr(age_input, creatinine_input, is_male_input)

if egfr_result is not None:
    print("Estimated Glomerular Filtration Rate (eGFR):", round(egfr_result, 2), "mL/min/1.73m²")


#Test cases
#Case-1: 
'''
Values:
Enter patient's age: 45
Enter serum creatinine level (mg/dL): 1.2
Enter patient's gender (M/F): M

Value by code: 69.59 mL/min/1.73m
Value online: 65.5-79.4 mL/min/1.73m 
'''
#Case-2: 
'''
Values:
Enter patient's age: 55
Enter serum creatinine level (mg/dL): 2.2
Enter patient's gender (M/F): M

Value by code: 33.19 mL/min/1.73m
Value online: 31.2-39.9 mL/min/1.73m 
'''
#Case-3: 
'''
Values:
Enter patient's age: 20
Enter serum creatinine level (mg/dL): 0.5
Enter patient's gender (M/F): M

Value by code: 225.32 mL/min/1.73m
Value online: 212.0-256.9 mL/min/1.73m 
'''
#Case-4: 
'''
Values:
Enter patient's age: 24
Enter serum creatinine level (mg/dL): 2.0
Enter patient's gender (M/F): F

Value by code: 32.53 mL/min/1.73m
Value online: 30.6-37.1 mL/min/1.73m 
'''
#Case-5: 
'''
Values:
Enter patient's age: 60
Enter serum creatinine level (mg/dL): 0.2
Enter patient's gender (M/F): M

Value by code: 518.99 mL/min/1.73m
Value online: 488.3-591.8 mL/min/1.73m 
'''
#Case-6: 
'''
Values:
Enter patient's age: 15
Enter serum creatinine level (mg/dL): 1.5
Enter patient's gender (M/F): M

Value by code: 67.23 mL/min/1.73m
Value online: 63.3-76.7 mL/min/1.73m 
'''
#Case-7: 
'''
Values:
Enter patient's age: 44
Enter serum creatinine level (mg/dL): 0.9
Enter patient's gender (M/F): F

Value by code: 72.29 mL/min/1.73m
Value online: 68.0-82.4 mL/min/1.73m 
'''
#Case-8: 
'''
Values:
Enter patient's age: 90
Enter serum creatinine level (mg/dL): 0.6
Enter patient's gender (M/F): M

Value by code: 134.53 mL/min/1.73m
Value online: 126.6-153.4 mL/min/1.73m 
'''
#Case-9: 
'''
Values:
Enter patient's age: 39
Enter serum creatinine level (mg/dL): 5.5
Enter patient's gender (M/F): F

Value by code: 9.17 mL/min/1.73m
Value online: 11.6-14.1 mL/min/1.73m 
'''
#Case-10: 
'''
Values:
Enter patient's age: 80
Enter serum creatinine level (mg/dL): 3.3
Enter patient's gender (M/F): F

Value by code: 14.3 mL/min/1.73m
Value online: 13.5-16.3 mL/min/1.73m 
'''