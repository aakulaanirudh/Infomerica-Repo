from flask import Flask, request, render_template_string
import mysql.connector as c

app = Flask(__name__)

# HTML template
index_html = '''
<!DOCTYPE html>
<html>
<head>
    <title>Employee Data Entry</title>
</head>
<body>
    <h1>Employee Data Entry</h1>
    <form method="POST" action="/">
        <label for="Employee_id">Employee ID:</label>
        <input type="number" name="Employee_id" required><br>

        <label for="Employee_name">Employee Name:</label>
        <input type="text" name="Employee_name" required><br>

        <label for="Date_of_joining">Date of Joining:</label>
        <input type="date" name="Date_of_joining" required><br>

        <label for="Date_of_birth">Date of Birth:</label>
        <input type="date" name="Date_of_birth" required><br>

        <label for="Status">Status:</label>
        <input type="text" name="Status" required><br>

        <label for="Reporting_Manager">Reporting Manager:</label>
        <input type="text" name="Reporting_Manager" required><br>

        <input type="submit" value="Submit">
    </form>
    <p>{{ message }}</p>
</body>
</html>
'''

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            Employee_id = int(request.form['Employee_id'])
            Employee_name = request.form['Employee_name']
            Date_of_joining = request.form['Date_of_joining']
            Date_of_birth = request.form['Date_of_birth']
            Status = request.form['Status']
            Reporting_Manager = request.form['Reporting_Manager']

            # Connect to the database and insert data (same code as before)
            con = c.connect(host="localhost", user="root", passwd="Anirudh@03", database="infomerica")
            cursor = con.cursor()

            query = "INSERT INTO employee_data (employee_id, employee_name, date_of_joining, date_of_birth, status, reporting_manager) VALUES (%s, %s, %s, %s, %s, %s)"
            values = (Employee_id, Employee_name, Date_of_joining, Date_of_birth, Status, Reporting_Manager)

            cursor.execute(query, values)
            con.commit()

            cursor.close()
            con.close()

            message = "Data inserted successfully"
        except Exception as e:
            message = f"Error: {str(e)}"
    else:
        message = ""

    return render_template_string(index_html, message=message)

if __name__ == '__main__':
    app.run(debug=True)
