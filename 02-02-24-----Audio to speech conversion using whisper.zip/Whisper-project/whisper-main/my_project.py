import whisper

model = whisper.load_model("base")
result = model.transcribe("imagine-dragons.mpeg")
print(result["text"])