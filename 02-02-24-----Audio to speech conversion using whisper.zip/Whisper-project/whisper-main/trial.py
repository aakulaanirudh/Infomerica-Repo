import whisper
from tkinter import Tk, filedialog
from pydub import AudioSegment

# Function to ask user for audio file path
def get_audio_file_path():
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(title="Select Audio File", filetypes=(("Audio files", "*.mp3;*.wav;*.flac"), ("All files", "*.*")))
    root.destroy()
    return file_path

# Get audio file path from user
audio_file_path = get_audio_file_path()

# Load audio file
audio = AudioSegment.from_file(audio_file_path)

# Convert to WAV format
wav_audio_path = audio_file_path[:-4] + ".wav"  # Change extension to .wav
audio.export(wav_audio_path, format="wav")

# Load whisper model
model = whisper.load_model("base")

# Transcribe WAV audio
result = model.transcribe(wav_audio_path)

# Print transcription result
print(result["text"])
