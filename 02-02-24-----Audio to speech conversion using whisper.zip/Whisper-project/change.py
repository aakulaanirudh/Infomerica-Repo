import whisper

# Load the pre-trained Whisper model
model = whisper.load_model("base")

# Transcribe speech from an audio file
result = model.transcribe("imagine-dragons.mpeg")
print("Transcription:", result["text"])

# Lower-level access: detect spoken language and decode audio
audio = whisper.load_audio("imagine-dragons.mpeg")
audio = whisper.pad_or_trim(audio)
mel = whisper.log_mel_spectrogram(audio).to(model.device)

# Detect the spoken language
_, probs = model.detect_language(mel)
detected_language = max(probs, key=probs.get)
print("Detected language:", detected_language)

# Decode the audio
options = whisper.DecodingOptions()
result = whisper.decode(model, mel, options)
print("Decoded text:", result.text)
