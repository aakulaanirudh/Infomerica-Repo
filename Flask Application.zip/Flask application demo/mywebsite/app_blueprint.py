from flask import Blueprint

app_blueprint= Blueprint('app_blueprint',__name__) 

@app_blueprint.route('/')
def hello_world():
    return "<h1>Welcome to Infomerica</h1>"


@app_blueprint.route('/about')
def about_page():
    return "<h1>about the page</h1>"


@app_blueprint.route('/contact')
def contact():
    return "<h1>find the contact details here.Thanks</h1>"