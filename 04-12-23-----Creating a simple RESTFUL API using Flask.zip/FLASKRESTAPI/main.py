from flask import Flask, jsonify
app = Flask(__name__)

@app.route('/')
def hello_world():
    return "hello,world!"

@app.route('/evenodd/<int:n>')
def evenodd(n):
    if n % 2 == 0:
        result = {
            "number": n,
            "result":'Even',
            "Server IP": '122.1.11.88'
        }
        
    
    else:
        result = {
            "number": n,
            "result":'Odd',
            "Server IP": '122.1.11.88'
        }
    return jsonify(result)

if __name__=="__main__" :
    app.run(debug=True)