from flask import Flask, render_template, request, jsonify
import json

app = Flask(__name__)

# Load employee data from a JSON file in the same directory
with open('employee_data.json', 'r') as file:
    data = json.load(file)

@app.route('/')
def index():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Employee Data Entry</title>
    </head>
    <body>
        <h1>EMPLOYEE DATA</h1>
        Employee_Id <input type="number" id="Employee_Id" onkeyup="autoFill()"/><br/>
        Employee_Name <input type="text" id="Employee_Name" /><br/>
        Date_of_joining <input type="text" id="Date_of_joining" /><br/>
        Date_of_birth <input type="text" id="Date_of_birth" /><br/>
        Status <input type="text" id="Status" /><br/>
        Reporting_Manager <input type="text" id="Reporting_Manager" /><br/>
        
        <script>
        function autoFill() {
            var employeeId = document.getElementById('Employee_Id').value;
            var employeeNameField = document.getElementById('Employee_Name');
            var dateOfJoiningField = document.getElementById('Date_of_joining');
            var dateOfBirthField = document.getElementById('Date_of_birth');
            var statusField = document.getElementById('Status');
            var reportingManagerField = document.getElementById('Reporting_Manager');

            // Initialize all fields as blank
            employeeNameField.value = '';
            dateOfJoiningField.value = '';
            dateOfBirthField.value = '';
            statusField.value = '';
            reportingManagerField.value = '';

            fetch(`/get_employee_data?Employee_Id=${employeeId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        // Populate the fields only if data is available
                        employeeNameField.value = data.Employee_Name;
                        statusField.value = data.Status;
                        reportingManagerField.value = data.Reporting_Manager;

                        // Convert and format the Date_of_joining and Date_of_birth fields
                        var dateOfJoining = new Date(data.Date_of_joining);
                        if (!isNaN(dateOfJoining.getTime())) {
                            dateOfJoiningField.value = formatDate(dateOfJoining);
                        }

                        var dateOfBirth = new Date(data.Date_of_birth);
                        if (!isNaN(dateOfBirth.getTime())) {
                            dateOfBirthField.value = formatDate(dateOfBirth);
                        }
                    }
                });
        }

        function formatDate(date) {
            var dd = String(date.getDate()).padStart(2, '0');
            var mm = String(date.getMonth() + 1).padStart(2, '0'); // January is 0!
            var yyyy = date.getFullYear();
            return dd + '-' + mm + '-' + yyyy;
        }
        </script>
    </body>
    </html>
    '''

@app.route('/get_employee_data', methods=['GET'])
def get_employee_data():
    employee_id = int(request.args.get('Employee_Id'))
    for employee in data:
        if employee['0'] == employee_id:
            return jsonify({
                "Employee_Name": employee['1'],
                "Date_of_joining": employee['2'],
                "Date_of_birth": employee['3'],
                "Status": employee['4'],
                "Reporting_Manager": employee['5']
            })
    return jsonify({})  # Return an empty JSON object if no matching data is found

if __name__ == '__main__':
    app.run(debug=True)
